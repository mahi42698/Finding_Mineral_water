# Custom Map Project

## Description
This project is a custom map, where I added icons marking places is Kondhwa

## Technologies used
- HTML
- CSS
- JavaScript
- Google Maps API


